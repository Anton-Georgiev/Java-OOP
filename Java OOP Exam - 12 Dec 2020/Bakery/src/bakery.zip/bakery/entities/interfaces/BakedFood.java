package bakery.entities.interfaces;

public interface BakedFood {
    String getName();

    double getPortion();

    double getPrice();
}

package Telephony.Interfaces;

public interface Callable {
    String call();
}

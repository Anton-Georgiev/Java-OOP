package Telephony.Interfaces;

public interface Browsable {
    String browse();
}

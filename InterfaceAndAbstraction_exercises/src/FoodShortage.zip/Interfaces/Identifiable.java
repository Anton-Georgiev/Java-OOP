package Interfaces;

public interface Identifiable {
    String getId();

}

package Interfaces;

public interface Birthable {
    String getBirthDate();

}

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        String command = scr.nextLine();

        List<Birthable> birthableList = new ArrayList<>();

        while (!command.equals("End")){
            String[] token = command.split(" ");
            switch (token[0]){
                case "Citizen":
                    birthableList.add(new Citizen(token[1], Integer.parseInt(token[2]), token[3], token[4]));
                    break;
                case "Robot":
                    command = scr.nextLine();
                    continue;
                case "Pet":
                    birthableList.add(new Pet(token[1], token[2]));
                    break;
            }

            command=  scr.nextLine();
        }

        String yearToShow = scr.nextLine();
        boolean hasOutput = false;


        for (Birthable birthable : birthableList) {
            if (birthable.getBirthDate().endsWith(yearToShow)){
                System.out.println(birthable.getBirthDate());
                hasOutput =true;
            }
        }

        if (!hasOutput){
            System.out.println("<no output>");
        }
    }
}

package viceCity.models.players;

public class MainPlayer extends BasePlayer{
    private static String name = "Tommy Vercetti";
    private static int lifePoints =100;
    public MainPlayer() {
        super(name,lifePoints);
    }
}

package viceCity.repositories.interfaces;

import viceCity.models.guns.Gun;

import java.util.Collection;

public class GunRepository implements Repository{
    private Collection<Gun> models;
    @Override
    public Collection<Gun> getModels() {
        return null;
    }

    @Override
    public void add(Object model) {

    }

    @Override
    public boolean remove(Object model) {
        return false;
    }

    @Override
    public Object find(String name) {
        return null;
    }
}

package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.CivilPlayer;
import viceCity.models.players.Player;

import java.util.Collection;
import java.util.List;

public class GangNeighbourhood implements Neighbourhood {
    public GangNeighbourhood(){

    }
    @Override
    public void action(Player mainPlayer, List<Player> civilPlayers) {

        int civilsSize = civilPlayers.size();

        for (int i = 0; i < civilsSize; i++) {
            List<Gun> mainPlayerGuns = mainPlayer.getGunRepository().getModels().stream().toList();
            CivilPlayer currCivil = (CivilPlayer) civilPlayers.get(i);

            while (mainPlayer.isAlive() && !mainPlayerGuns.isEmpty()) {
                for (Gun currMainPlayerGun : mainPlayerGuns) {

                    if (currMainPlayerGun.getBulletsPerBarrel() == 0 && currMainPlayerGun.getTotalBullets() == 0) {
                        continue;
                    }

                    if (!currCivil.isAlive()) {
                        civilPlayers.remove(currCivil);
                        break;
                    }

                    int pointsToTake = currMainPlayerGun.fire();
                    currCivil.takeLifePoints(pointsToTake);
                }
                if (!currCivil.isAlive()) {
                    break;
                }
            }
            if (!currCivil.isAlive()) {
                break;
            }
        }


        for (Player currCivilPlayer : civilPlayers) {
           List<Gun> currCivilPlayerGunList = currCivilPlayer.getGunRepository().getModels().stream().toList();
            for (Gun gun : currCivilPlayerGunList) {

                if (gun.canFire()){

                    mainPlayer.takeLifePoints(gun.fire());
                    if (!mainPlayer.isAlive()){
                        break;
                    }
                }
                if (!mainPlayer.isAlive()){
                    break;
                }
            }
            if (!mainPlayer.isAlive()){
                break;
            }
        }
    }
}

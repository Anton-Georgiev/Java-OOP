package spaceStation.models.astronauts;

public class Meteorologist extends BaseAstronaut{
    private static final int OXYGEN_VALUE = 90;
    protected Meteorologist(String name) {
        super(name, OXYGEN_VALUE);
    }
}

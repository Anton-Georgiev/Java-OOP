package Vehicles;

import java.text.DecimalFormat;

public class Car extends Vehicle{
    private static final double AIR_CONDITIONER_ADDIT_FUEL= 0.9;

    protected Car(double fuel, double consumption) {
        super(fuel, consumption + AIR_CONDITIONER_ADDIT_FUEL);

    }
}

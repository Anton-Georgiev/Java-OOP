package Vehicles;

import java.util.IllegalFormatCodePointException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        String[] token = scr.nextLine().split("\\s+");
        Vehicle car = new Car(Double.parseDouble(token[1]), Double.parseDouble(token[2]));
        token = scr.nextLine().split("\\s+");

        Vehicle truck = new Truck(Double.parseDouble(token[1]), Double.parseDouble(token[2]));

        int commandsCount = Integer.parseInt(scr.nextLine());
        while (commandsCount-- >0){

            String[] commands = scr.nextLine().split("\\s+");
            double argument = Double.parseDouble(commands[2]);
            if (commands[0].contains("Drive")){
                if (commands[1].equals("Car")){
                    System.out.println(car.drive(argument));
                }else{
                    System.out.println(truck.drive(argument));
                }
            } else {
                if (commands[1].equals("Car")){
                    car.refuel(argument);
                }else {
                    truck.refuel(argument);
                }
            }
        }
        System.out.println(car);
        System.out.println(truck);
    }
}

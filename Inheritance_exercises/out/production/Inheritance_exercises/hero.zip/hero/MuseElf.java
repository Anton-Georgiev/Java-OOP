package hero;

public class MuseElf extends Elf{
    public MuseElf(String user, int level){
        super(user, level);
    }
}

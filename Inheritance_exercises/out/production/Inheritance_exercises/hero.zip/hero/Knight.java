package hero;

public class Knight extends Hero {
    public Knight(String user, int level){
        super(user, level);
    }
}

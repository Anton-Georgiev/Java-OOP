package hero;

public class DarkKnight extends Knight {
    public DarkKnight(String user, int level){
        super(user, level);
    }

}

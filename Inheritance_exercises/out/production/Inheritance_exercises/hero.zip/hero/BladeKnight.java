package hero;

public class BladeKnight extends DarkKnight{
    public BladeKnight(String user, int level){
        super(user,level);
    }
}

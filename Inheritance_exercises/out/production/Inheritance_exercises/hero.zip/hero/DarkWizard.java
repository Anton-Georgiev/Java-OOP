package hero;

public class DarkWizard extends Wizard{
    public DarkWizard(String user, int level){
        super(user, level);
    }
}

package hero;

public class Wizard extends Hero{
    public Wizard(String user, int level){
        super(user,level);
    }

}

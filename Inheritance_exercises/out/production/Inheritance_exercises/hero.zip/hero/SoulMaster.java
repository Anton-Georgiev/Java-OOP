package hero;

public class SoulMaster extends DarkWizard{
    private SoulMaster(String user, int level){
        super(user, level);
    }
}

 public enum Color {
        RED,
        GREEN,
        YELLOW;
    }



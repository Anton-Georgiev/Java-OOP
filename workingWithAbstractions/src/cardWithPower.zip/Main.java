import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String rank = scanner.nextLine();
        String colour = scanner.nextLine();

        Card card = new Card(CardSuits.valueOf(colour), CardRanks.valueOf(rank));

        System.out.printf("Card name: %s of %s; Card power: %d", rank, colour, card.getPower());
    }
}

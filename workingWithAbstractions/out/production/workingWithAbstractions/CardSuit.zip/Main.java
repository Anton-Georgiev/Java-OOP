public class Main {
    public static void main(String[] args) {
//        Card Suits:
//Ordinal value: 0; Name value: CLUBS

        System.out.println("Card Suits:");
        for (CardSuit suit : CardSuit.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n", suit.ordinal(), suit.toString());
        }

//        for (int i = CardSuit.values()[0].getValue(); i <CardSuit.values().length ; i++) {
//            System.out.println(CardSuit.values()[i]);
//        }
    }
}

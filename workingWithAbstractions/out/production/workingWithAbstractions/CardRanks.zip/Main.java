public class Main {
    public static void main(String[] args) {
//        Card Suits:
//Ordinal value: 0; Name value: CLUBS

        System.out.println("Card Ranks:");
        for (CardRanks rank : CardRanks.values()) {
            System.out.printf("Ordinal value: %d; Name value: %s%n", rank.ordinal(), rank.toString());
        }

//        for (int i = CardSuit.values()[0].getValue(); i <CardSuit.values().length ; i++) {
//            System.out.println(CardSuit.values()[i]);
//        }
    }
}

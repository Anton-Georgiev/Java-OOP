package restaurant.repositories;

import java.util.ArrayList;
import java.util.Collection;

public class TableRepositoryImpl<BaseTable> implements restaurant.repositories.interfaces.TableRepository<BaseTable> {
    private Collection<BaseTable> entities;

    public TableRepositoryImpl(){
        entities = new ArrayList<>();
    }

    @Override
    public Collection<BaseTable> getAllEntities() {
        return null;
    }

    @Override
    public void add(BaseTable entity) {

    }

    @Override
    public BaseTable byNumber(int number) {
        return null;
    }
}

package restaurant.repositories;

import java.util.ArrayList;
import java.util.Collection;

public class HealthFoodRepositoryImpl<Food> implements restaurant.repositories.interfaces.HealthFoodRepository<Food> {
    private Collection<Food> entities;

   public HealthFoodRepositoryImpl(){
       entities = new ArrayList<>();
   }

    @Override
    public Food foodByName(String name) {
        return null;
    }

    @Override
    public Collection<Food> getAllEntities() {
        return null;
    }

    @Override
    public void add(Food entity) {

    }
}

package restaurant.repositories;

import java.util.ArrayList;
import java.util.Collection;

public class BeverageRepositoryImpl<Beverage> implements restaurant.repositories.interfaces.BeverageRepository<Beverage> {
    private Collection<Beverage> entities;

    public BeverageRepositoryImpl(){
        entities = new ArrayList<>();
    }

    @Override
    public Beverage beverageByName(String drinkName, String drinkBrand) {
        return null;
    }

    @Override
    public Collection<Beverage> getAllEntities() {
        return null;
    }

    @Override
    public void add(Beverage entity) {

    }
}

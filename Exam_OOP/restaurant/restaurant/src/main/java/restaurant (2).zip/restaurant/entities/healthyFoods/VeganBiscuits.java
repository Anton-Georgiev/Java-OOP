package restaurant.entities.healthyFoods;

import restaurant.entities.healthyFoods.Food;

public class VeganBiscuits extends Food {
    private int InitialVeganBiscuitsPortion = 205;
    public VeganBiscuits(String name, double portion, double price) {
        super(name, portion, price);
    }
}

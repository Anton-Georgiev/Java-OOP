package restaurant.entities.healthyFoods;

import restaurant.entities.healthyFoods.Food;

public class Salad extends Food {
    private int initialSaladPortion = 150;
    public Salad(String name, double portion, double price) {
        super(name, portion, price);
    }
}

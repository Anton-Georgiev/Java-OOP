package restaurant.core;

import restaurant.core.interfaces.Controller;
import restaurant.entities.healthyFoods.Salad;
import restaurant.entities.healthyFoods.VeganBiscuits;
import restaurant.entities.healthyFoods.interfaces.HealthyFood;
import restaurant.entities.drinks.interfaces.Beverages;
import restaurant.entities.tables.interfaces.Table;
import restaurant.repositories.BeverageRepositoryImpl;
import restaurant.repositories.HealthFoodRepositoryImpl;
import restaurant.repositories.TableRepositoryImpl;
import restaurant.repositories.interfaces.*;

import static restaurant.common.ExceptionMessages.FOOD_EXIST;
import static restaurant.common.OutputMessages.FOOD_ADDED;

public class ControllerImpl implements Controller {
    private HealthFoodRepositoryImpl healthFoodRepository;
    private BeverageRepositoryImpl beverageRepository;
    private TableRepositoryImpl tableRepository;

    public ControllerImpl(HealthFoodRepository<HealthyFood> healthFoodRepository
            , BeverageRepository<Beverages> beverageRepository, TableRepository<Table> tableRepository) {

        healthFoodRepository = new HealthFoodRepositoryImpl();
        beverageRepository = new BeverageRepositoryImpl();
        tableRepository = new TableRepositoryImpl();
    }

    @Override
    public String addHealthyFood(String type, double price, String name) {
        HealthyFood food = null;
        switch (type){
            case "Salad" -> food = new Salad(name,price);
            case "VeganBiscuits" -> food = new VeganBiscuits(name,price);
        }
        if (healthFoodRepository.foodByName(name) != null){
            throw new IllegalArgumentException(String.format(FOOD_EXIST, name));
        }
        healthFoodRepository.add(food);
        return String.format(FOOD_ADDED, name);
    }

    @Override
    public String addBeverage(String type, int counter, String brand, String name){
        //TODO:
        return null;
    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {
        //TODO:
        return null;
    }

    @Override
    public String reserve(int numberOfPeople) {
        //TODO:
        return null;
    }

    @Override
    public String orderHealthyFood(int tableNumber, String healthyFoodName) {
        //TODO:
        return null;
    }

    @Override
    public String orderBeverage(int tableNumber, String name, String brand) {
        //TODO:
        return null;
    }

    @Override
    public String closedBill(int tableNumber) {
        //TODO:
        return null;
    }


    @Override
    public String totalMoney() {
        //TODO:
        return null;
    }
}

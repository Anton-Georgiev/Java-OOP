import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

//     String[] pizzaNameAndNumOfToppings = scanner.nextLine().split(" ");
//     String pizzaName = pizzaNameAndNumOfToppings[1];
//     String numOfTopping = pizzaNameAndNumOfToppings[2];
//
//     String[] doughInput = scanner.nextLine().split(" ");
//     String flourType = doughInput[1];
//     String bakingTechnique = doughInput[2];
//     int weightInGrams = Integer.parseInt(doughInput[3]);
//
//     String command = scanner.nextLine();
//     while (!command.equals("END")){
//         String toppingType = command.split(" ")[1];
//         int toppingWeightInGrams = Integer.parseInt(command.split(" ")[2]);
//         Topping topping = new Topping(toppingType, toppingWeightInGrams);
//         command =scanner.nextLine();
//     }

    }
}

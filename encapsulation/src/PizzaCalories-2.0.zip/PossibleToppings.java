public enum PossibleToppings {
    MEAT("meat"),
    VEGGIES("veggies"),
    CHEESE("cheese"),
    SAUCE("sauce");

    private String value;

    PossibleToppings(String value){
        this.value = value;
    }
}
